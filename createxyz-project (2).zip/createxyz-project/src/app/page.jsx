"use client";
import React from "react";

import { useHandleStreamResponse } from "../utilities/runtime-helpers";

function MainComponent() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [imageResults, setImageResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [overview, setOverview] = useState("");
  const [streamingOverview, setStreamingOverview] = useState("");
  const handleStreamResponse = useHandleStreamResponse({
    onChunk: setStreamingOverview,
    onFinish: setOverview,
  });
  const handleSearch = async () => {
    setLoading(true);
    setOverview("");
    setStreamingOverview("");

    try {
      const [webResponse, imageResponse, overviewResponse] = await Promise.all([
        fetch(
          `/integrations/google-search/search?q=${encodeURIComponent(query)}`
        ),
        fetch(
          `/integrations/image-search/imagesearch?q=${encodeURIComponent(
            query
          )}`
        ),
        fetch("/integrations/anthropic-claude-sonnet-3-5/", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: [
              {
                role: "user",
                content: `Give a very brief 2-3 sentence overview of: ${query}`,
              },
            ],
            stream: true,
          }),
        }),
      ]);

      const webData = await webResponse.json();
      const imageData = await imageResponse.json();
      setResults(webData.items || []);
      setImageResults(imageData.items || []);
      handleStreamResponse(overviewResponse);
    } catch (error) {
      console.error(error);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#0D0D0D] text-white p-6">
      <div
        className={`transition-all duration-700 ease-in-out ${
          !results.length
            ? "h-screen flex items-center justify-center"
            : "h-auto"
        }`}
      >
        <div
          className={`transition-all duration-700 ease-in-out transform ${
            results.length
              ? "max-w-full translate-y-0"
              : "w-full max-w-2xl translate-y-0"
          }`}
        >
          <div className="text-center mb-16">
            <h1 className="text-6xl font-bold text-[#B026FF] mb-2 font-montserrat drop-shadow-[0_0_8px_rgba(176,38,255,0.8)]">
              TimeMachine
            </h1>
            <h2 className="text-5xl font-bold text-[#B026FF] font-montserrat drop-shadow-[0_0_8px_rgba(176,38,255,0.8)]">
              Search.
            </h2>
          </div>
          <div className={`relative ${loading ? "loading-glow" : ""}`}>
            <div className="relative">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                placeholder="Search anything..."
                className="w-full bg-[#B026FF] text-white rounded-lg px-6 py-4 pr-12 outline-none placeholder-white/70 text-lg shadow-[0_0_15px_rgba(176,38,255,0.5)]"
              />
              <button
                onClick={handleSearch}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-white"
              >
                <i className="fas fa-search text-xl"></i>
              </button>
            </div>
          </div>

          {loading ? (
            <div></div>
          ) : (
            <>
              {results.length > 0 ? (
                <div className="flex gap-6">
                  <div className="flex-1 border-r-2 border-[#B026FF] pr-6">
                    {(overview || streamingOverview) && (
                      <div className="mt-8 p-6 bg-[#B026FF]/10 rounded-lg border border-[#B026FF] shadow-[0_0_15px_rgba(176,38,255,0.3)]">
                        <p className="text-[#B026FF]/60 mb-2 text-sm">
                          TimeMachine's message
                        </p>
                        <p className="text-[#B026FF] drop-shadow-[0_0_3px_rgba(176,38,255,0.8)]">
                          {overview || streamingOverview}
                        </p>
                      </div>
                    )}
                    <div className="space-y-6 mt-8">
                      {results.map((result, index) => (
                        <div
                          key={index}
                          className="bg-[#B026FF]/10 p-6 rounded-lg hover:bg-[#B026FF]/20 transition-all duration-300 border border-[#B026FF] shadow-[0_0_15px_rgba(176,38,255,0.3)]"
                        >
                          <a
                            href={result.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[#B026FF] text-xl mb-2 block hover:underline drop-shadow-[0_0_3px_rgba(176,38,255,0.8)]"
                          >
                            {result.title}
                          </a>
                          <p className="text-[#B026FF]/60 text-sm mb-2">
                            {result.displayLink}
                          </p>
                          <p className="text-gray-400">{result.snippet}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex-1 pl-6">
                    <div className="grid grid-cols-2 gap-4">
                      {imageResults.map((result, index) => (
                        <div
                          key={index}
                          className="bg-[#FFE135]/10 p-4 rounded-lg hover:bg-[#FFE135]/20 transition-all duration-300"
                        >
                          <img
                            src={result.thumbnailImageUrl}
                            alt={result.title}
                            className="w-full h-48 object-cover rounded-lg mb-2"
                          />
                          <a
                            href={result.contextLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[#FFE135] text-sm block hover:underline"
                          >
                            {result.title}
                          </a>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : null}
            </>
          )}
        </div>
      </div>
      <style jsx global>{`
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .space-y-6 > div {
          animation: slideIn 0.3s ease-out forwards;
        }

        @keyframes glowPulse {
          0% {
            box-shadow: 0 0 5px #B026FF, 0 0 10px #B026FF, 0 0 15px #B026FF;
          }
          50% {
            box-shadow: 0 0 15px #B026FF, 0 0 30px #B026FF, 0 0 45px #B026FF;
          }
          100% {
            box-shadow: 0 0 5px #B026FF, 0 0 10px #B026FF, 0 0 15px #B026FF;
          }
        }

        .loading-glow::before {
          content: '';
          position: absolute;
          inset: 0;
          border-radius: 12px;
          animation: glowPulse 1.5s ease-in-out infinite;
          pointer-events: none;
        }

        @keyframes fadeSlide {
          from {
            opacity: 0;
            transform: translateX(-20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes moveUp {
          from {
            transform: translateY(0);
          }
          to {
            transform: translateY(-40vh);
          }
        }

        .flex > div {
          animation: fadeSlide 0.5s ease-out forwards;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;